﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SystemaClass
{
    public class Systems
    {
        public double urav(double a, double b, double c, double x)
        {
            double F;
            if ((x - 1) < 0 && (b - x != 0))
            {
                F = a * Math.Pow(x, 3) + b;
            }
            else if ((x - 1) > 0 && (b + x == 0))
            {
                F = (x - a) / x;
            }
            else F = x / c;
            return F;
        }
    }
}
