﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using SystemaClass;

namespace SystemaTest
{
    [TestClass]
    public class SysTest
    {
        [TestMethod]
        public void uravnenie()
        {
            //arrange
            double a = 2;
            double b = 1;
            double c = 2;
            double x = 6;
            double expected = 3;
            //ast
            Systems m = new Systems();
            double actual = m.urav(a, b, c, x);
            //assert
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void uravnenie1()
        {
            //arrange
            double a = 3;
            double b = 7;
            double c = 5;
            double x = 0;
            double expected = 7;
            //ast
            Systems m = new Systems();
            double actual = m.urav(a, b, c, x);
            //assert
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void uravnenie2()
        {
            //arrange
            double a = 5;
            double b = -10;
            double c = 1;
            double x = 10;
            double expected = 0.5;
            //ast
            Systems m = new Systems();
            double actual = m.urav(a, b, c, x);
            //assert
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void uravnenie3()
        {
            //arrange
            double a = 67;
            double b = -10;
            double c = 1;
            double x = -2;
            double expected = 4;
            //ast
            Systems m = new Systems();
            double actual = m.urav(a, b, c, x);
            //assert
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void uravnenie4()
        {
            //arrange
            double a = 9;
            double b = 0;
            double c = 6;
            double x = 10;
            double expected = 21;
            //ast
            Systems m = new Systems();
            double actual = m.urav(a, b, c, x);
            //assert
            Assert.AreEqual(expected, actual);
        }
    }
}
